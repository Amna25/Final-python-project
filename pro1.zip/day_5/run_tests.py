import unittest
 
from tests.country_test import TestCountry
from tests.city_test import TestCity
from tests.destination_test import TestDestination
 
if __name__ == '__main__':
    unittest.main()