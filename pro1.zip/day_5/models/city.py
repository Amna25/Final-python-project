class City:

    def __init__(self, name, visited, country, id=None):
        self.name=name
        self.visited=visited
        self.country=country
        self.id=id